class InitObj{
    constructor(user,profiles,orderMealItems){
        this.user = user;
        this.profiles = profiles;
        this.orderMealItems = orderMealItems;    
    }
}

module.exports = InitObj;