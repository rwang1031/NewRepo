class Profile{
    constructor(id,firstName,lastName,location,dayOfBirth,userId){
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.location = location;
        this.dayOfBirth = dayOfBirth;
        this.userId = userId
    }
}

module.exports = Profile;