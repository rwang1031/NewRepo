
class MealItem{
    constructor(){
            this.id = 1,
            this.typeid= 1,
            this.subTypeId= 2,
            this.menuItemId = 0,
           
            this.sides=[1],           
            this.drinks=[2],
            this.juices=[2],
            this.condiments =[2,3],

            this.intendDeliverDate ='2020-12-06',
            this.profileId = 2   
    }
}
module.exports = MealItem;