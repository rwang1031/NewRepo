
class MealItemSubTypeRef{
    constructor(id,displayName,price){
            this.id = id,
            this.displayName = displayName    
            // this.id = 1,
            // this.displayName = "Junior Meal"          
    }
}
module.exports = MealItemSubTypeRef;