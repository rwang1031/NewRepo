
class SideRef{
    constructor(id,displayName){
            this.id = id,
            this.displayName = displayName
            // this.id = 1,
            // this.displayName = "Cucumber"        
    }
}
module.exports = SideRef;