
class CondimentRef{
    constructor(id,displayName){
            this.id = id,
            this.displayName = displayName
            // this.id = 1,
            // this.displayName = "Ketchup"        
    }
}
module.exports = CondimentRef;