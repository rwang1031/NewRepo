
class JuiceRef{
    constructor(id,displayName){
            this.id = id,
            this.displayName = displayName
            // this.id = 2,
            // this.displayName = "Orange Juice"        
    }
}
module.exports = JuiceRef;